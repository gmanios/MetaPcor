# MetaPcor
Meta-analysis of gene expression studies using partial correlation as effect size
